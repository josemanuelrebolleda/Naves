package com.W2M.naves;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarshipsApplicationTests {

	@Test
	void contextLoads() {
	}

}
