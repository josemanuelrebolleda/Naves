package com.W2M.naves;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarshipsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StarshipsApplication.class, args);
	}

}
